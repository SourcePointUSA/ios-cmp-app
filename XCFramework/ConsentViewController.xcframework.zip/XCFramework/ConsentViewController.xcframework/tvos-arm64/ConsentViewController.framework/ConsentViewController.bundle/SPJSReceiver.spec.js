require("./SPJSReceiver")

it.skip("SPJSReceiver", () => {
    
})
