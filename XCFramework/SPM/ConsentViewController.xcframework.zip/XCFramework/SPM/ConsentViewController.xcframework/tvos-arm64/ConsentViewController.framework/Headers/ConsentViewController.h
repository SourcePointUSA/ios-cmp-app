#import <Foundation/Foundation.h>

FOUNDATION_EXPORT double ConsentViewControllerVersionNumber;
FOUNDATION_EXPORT const unsigned char ConsentViewControllerVersionString[];
